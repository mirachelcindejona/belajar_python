# Nama: Mirachel Cindejona
# NIM : 2401638
# Kelas : 1B-RPL

# ==========2==========
# Tuple yang berisi daftar pasangan (latitude, longitude) sebuah lokasi
jakarta = (-6.2088, 106.8456)
bandung = (-6.9175, 107.6191)
surabaya = (-7.2575, 112.7521)
lokasi = (jakarta, bandung, surabaya)
print(f'Tuple yang berisi daftar pasangan (latitude, longitude) sebuah lokasi sebagai berikut:')
print(f'Jakarta {jakarta}')
print(f'Bandung {bandung}')
print(f'Surabaya {surabaya}\n')

# ==========2-A==========
# Menampilkan Data koordinat kota bandung
print(f"-Data koordinat kota Bandung: {bandung}")

# ==========2-B==========
# Menampilkan jumlah lokasi yang tersimpan
print(f"-Jumlah lokasi yang tersimpan: {len(lokasi)}")