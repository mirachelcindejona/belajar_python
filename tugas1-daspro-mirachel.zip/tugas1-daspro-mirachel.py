# Nama: Mirachel Cindejona
# NIM : 2401638
# Kelas : 1B-RPL

nama = input("Masukkan nama Anda : ")
umur = input("Masukkan umur Anda : ")
print(f"Selamat datang {nama}, umur kamu adalah {umur} tahun")