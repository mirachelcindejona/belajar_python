# Nama: Mirachel Cindejona
# NIM : 2401638
# Kelas : 1B-RPL

# Kalkulator pertambahan

a = int(input("Masukkan bilangan 1 : "))
b = int(input("Masukkan bilangan 2 : "))
c = int(input("Masukkan bilangan 3 : "))
hasil = a + b + c
print(f"Hasil dari penjumlahan {a} + {b} + {c} = {hasil}")